from selenium import webdriver
from selenium.webdriver.common.by import By
import time

def auto_fill_pan_application(url, name, email, dob, phone, address, fathers_name, mothers_name):
    driver = webdriver.Chrome()
    driver.get(url)

    input_names = ["Field1", "Field8", "Field7", "Field10", "Field9", "Field3", "Field11"]

    input_values = [name, email, dob, phone, address, fathers_name, mothers_name]

    for input_name, value in zip(input_names, input_values):
        element = driver.find_element(By.ID, input_name)
        element.send_keys(value)

    submit_button = driver.find_element(By.ID, "saveForm")
    submit_button.click()

    time.sleep(5)

    driver.quit()

if __name__ == "__main__":
    pan_apply_url = "https://wufoonaresh.wufoo.com/forms/z6ww8xf1m69dvh/"

    name = input("Enter your full name: ")
    fathers_name = input("Enter your father's name: ")
    mothers_name = input("Enter your mother's name: ")
    dob = input("Enter your date of birth (YYYY-MM-DD): ")
    address = input("Enter your address: ")
    email = input("Enter your email address: ")
    phone = input("Enter your phone number: ")

    auto_fill_pan_application(pan_apply_url, name, email, phone, dob  , address, fathers_name, mothers_name)
